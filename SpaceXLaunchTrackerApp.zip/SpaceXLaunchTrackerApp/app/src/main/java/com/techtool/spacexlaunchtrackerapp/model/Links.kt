package com.techtool.spacexlaunchtrackerapp.model

data class Links(
    val mission_patch: String?,
    val article_link: String?,
    val video_link: String?
)