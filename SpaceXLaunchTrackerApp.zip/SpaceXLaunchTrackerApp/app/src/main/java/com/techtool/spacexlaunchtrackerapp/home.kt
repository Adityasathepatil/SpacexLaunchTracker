package com.techtool.spacexlaunchtrackerapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.techtool.spacexlaunchtrackerapp.adapter.LaunchAdapter
import com.techtool.spacexlaunchtrackerapp.databinding.FragmentHomeBinding
import com.techtool.spacexlaunchtrackerapp.viewmodel.DetailViewModel
import com.techtool.spacexlaunchtrackerapp.viewmodel.HomeViewModel

class home : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private val homeViewModel: HomeViewModel by activityViewModels()
    private val detailViewModel: DetailViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = LaunchAdapter {
            detailViewModel.setLaunch(it)


            findNavController().navigate(R.id.action_homeFragment_to_detailFragment)
        }

        binding.recyclerViewLaunches.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewLaunches.adapter = adapter

        homeViewModel.launches.observe(viewLifecycleOwner) { launches ->
            adapter.submitList(launches)
        }
    }
}