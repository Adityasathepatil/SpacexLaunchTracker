package com.techtool.spacexlaunchtrackerapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.techtool.spacexlaunchtrackerapp.model.Launch
import com.techtool.spacexlaunchtrackerapp.repository.LaunchRepository
import kotlinx.coroutines.launch


class HomeViewModel : ViewModel() {

    val launches: MutableLiveData<List<Launch>> = MutableLiveData()
    private val repository = LaunchRepository()

    init {
        fetchLaunches()
    }

    private fun fetchLaunches() {
        viewModelScope.launch {
            val response = repository.getLaunches()
            if (response.isSuccessful) {
                launches.postValue(response.body())
            }
        }
    }
}