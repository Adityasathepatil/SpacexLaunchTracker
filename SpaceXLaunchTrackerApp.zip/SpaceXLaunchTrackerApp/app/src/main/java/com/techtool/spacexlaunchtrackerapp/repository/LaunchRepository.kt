package com.techtool.spacexlaunchtrackerapp.repository

import com.techtool.spacexlaunchtrackerapp.network.RetrofitClient

class LaunchRepository {
    suspend fun getLaunches() = RetrofitClient.apiService.getLaunches()
}