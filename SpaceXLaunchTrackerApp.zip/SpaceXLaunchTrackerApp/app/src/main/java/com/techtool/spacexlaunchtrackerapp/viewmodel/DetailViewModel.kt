package com.techtool.spacexlaunchtrackerapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.techtool.spacexlaunchtrackerapp.model.Launch

class DetailViewModel : ViewModel() {
    val selectedLaunch: MutableLiveData<Launch> = MutableLiveData()

    fun setLaunch(launch: Launch) {
        selectedLaunch.value = launch
    }
}