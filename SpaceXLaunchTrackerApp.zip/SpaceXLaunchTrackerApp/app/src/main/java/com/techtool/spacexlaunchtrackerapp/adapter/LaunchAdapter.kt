package com.techtool.spacexlaunchtrackerapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.techtool.spacexlaunchtrackerapp.databinding.ItemLaunchBinding
import com.techtool.spacexlaunchtrackerapp.model.Launch

class LaunchAdapter(private val onClick: (Launch) -> Unit) : ListAdapter<Launch, LaunchAdapter.LaunchViewHolder>(LaunchDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LaunchViewHolder {
        val binding = ItemLaunchBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LaunchViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LaunchViewHolder, position: Int) {
        val launch = getItem(position)
        holder.bind(launch)
    }

    inner class LaunchViewHolder(private val binding: ItemLaunchBinding) : RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val launch = getItem(position)
                    onClick(launch)
                }
            }
        }

        fun bind(launch: Launch) {
            binding.apply {
                missionName.text = launch.mission_name
                launchYear.text = launch.launch_year
                rocketName.text = launch.rocket.rocket_name
            }
        }
    }

    class LaunchDiffCallback : DiffUtil.ItemCallback<Launch>() {
        override fun areItemsTheSame(oldItem: Launch, newItem: Launch): Boolean {
            return oldItem.flight_number == newItem.flight_number
        }

        override fun areContentsTheSame(oldItem: Launch, newItem: Launch): Boolean {
            return oldItem == newItem
        }
    }
}