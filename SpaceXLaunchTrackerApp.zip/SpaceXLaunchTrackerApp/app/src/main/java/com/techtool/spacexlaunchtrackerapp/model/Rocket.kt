package com.techtool.spacexlaunchtrackerapp.model

data class Rocket(
    val rocket_name: String,
    val rocket_type: String
)
