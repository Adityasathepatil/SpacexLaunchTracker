package com.techtool.spacexlaunchtrackerapp.model

data class Launch(
    val flight_number: Int,
    val mission_name: String,
    val launch_year: String,
    val rocket: Rocket,
    val launch_site: LaunchSite,
    val links: Links,
    val details: String?
)