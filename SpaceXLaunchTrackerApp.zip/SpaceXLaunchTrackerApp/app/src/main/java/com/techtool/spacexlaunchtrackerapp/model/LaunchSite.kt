package com.techtool.spacexlaunchtrackerapp.model

data class LaunchSite(
    val site_name_long: String
)