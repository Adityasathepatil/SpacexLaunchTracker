package com.techtool.spacexlaunchtrackerapp.network



import com.techtool.spacexlaunchtrackerapp.model.Launch
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {
    @GET("v3/launches")
    suspend fun getLaunches(): Response<List<Launch>>
}
