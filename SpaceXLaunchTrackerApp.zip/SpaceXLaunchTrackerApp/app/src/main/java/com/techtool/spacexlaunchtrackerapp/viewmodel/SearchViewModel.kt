package com.techtool.spacexlaunchtrackerapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.techtool.spacexlaunchtrackerapp.model.Launch
import com.techtool.spacexlaunchtrackerapp.repository.LaunchRepository
import kotlinx.coroutines.launch

class SearchViewModel : ViewModel() {

    val searchResults: MutableLiveData<List<Launch>> = MutableLiveData()
    private val repository = LaunchRepository()

    fun searchLaunches(query: String) {
        viewModelScope.launch {
            val response = repository.getLaunches()
            if (response.isSuccessful) {
                val launches = response.body() ?: emptyList()
                val filteredLaunches = launches.filter {
                    it.mission_name.contains(query, ignoreCase = true) ||
                            it.launch_year.contains(query, ignoreCase = true) ||
                            it.rocket.rocket_name.contains(query, ignoreCase = true)
                }
                searchResults.postValue(filteredLaunches)
            }
        }
    }
}