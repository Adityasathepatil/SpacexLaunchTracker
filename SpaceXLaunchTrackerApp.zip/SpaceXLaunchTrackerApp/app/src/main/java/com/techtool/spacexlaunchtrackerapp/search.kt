package com.techtool.spacexlaunchtrackerapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.techtool.spacexlaunchtrackerapp.adapter.LaunchAdapter
import com.techtool.spacexlaunchtrackerapp.databinding.FragmentSearchBinding
import com.techtool.spacexlaunchtrackerapp.viewmodel.SearchViewModel

class search : Fragment() {

    private lateinit var binding: FragmentSearchBinding
    private val searchViewModel: SearchViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = LaunchAdapter {

        }

        binding.recyclerViewSearchResults.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewSearchResults.adapter = adapter

        binding.searchEditText.addTextChangedListener { text ->
            searchViewModel.searchLaunches(text.toString())
        }

        searchViewModel.searchResults.observe(viewLifecycleOwner) { launches ->
            adapter.submitList(launches)
        }
    }
}